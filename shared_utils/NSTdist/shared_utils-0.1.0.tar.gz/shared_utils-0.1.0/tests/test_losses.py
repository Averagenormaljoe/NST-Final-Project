import pytest
from shared_utils.losses import get_artfid_loss, get_fid_loss, get_isc_loss, get_kernel_inception_distance
import tensorflow as tf
def get_test_images():
    base_image = tf.random.uniform((1, 112, 112, 3))
    combination_image = tf.random.uniform((1, 112, 112, 3))
    return base_image, combination_image


def test_artfid_loss():
    
    base_image, combination_image = get_test_images()

    artfid_loss = get_artfid_loss(base_image, combination_image)
    assert isinstance(artfid_loss, float)

def test_fid_loss():
    base_image, combination_image = get_test_images()

    fid_loss = get_fid_loss(base_image, combination_image)
    assert isinstance(fid_loss, float)

def test_isc_loss():
    base_image, combination_image = get_test_images()
    isc_loss = get_isc_loss(base_image, combination_image)
    assert isinstance(isc_loss, float)
def test_kid():
    base_image, combination_image = get_test_images()
    kid_loss = get_kernel_inception_distance(base_image, combination_image)
    assert isinstance(kid_loss, float)